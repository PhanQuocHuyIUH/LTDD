import React from 'react';
import Screen2 from './screens/screen2'

const App = () => {
  return (
    <Screen2/>
  );
};

export default App;